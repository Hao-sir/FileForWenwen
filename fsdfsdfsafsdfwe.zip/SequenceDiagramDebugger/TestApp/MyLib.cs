﻿namespace TestApp
{
	public class MyLib
	{
		public MyLib()
		{
		}

		public void Calculate()
		{
			MoreOperations();
		}

		public void MoreOperations()
		{
		}
	}
}
