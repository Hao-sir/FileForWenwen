﻿using SequenceDiagramDebuggerLib;
using System;
using System.Windows.Forms;

namespace TestApp
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();

			SequenceDiagramDebugger.Init(this, "TestApp.");
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			MyLib lib = new MyLib();
			lib.Calculate();
		}
	}
}
