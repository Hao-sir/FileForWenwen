﻿namespace SequenceDiagramDebuggerLib
{
	public class Method
	{
		public string ParticipantName = "";
		public string MethodName = "";

		public Method(string participantName, string methodName)
		{
			this.ParticipantName = participantName;
			this.MethodName = methodName + "()";
		}
	}
}
