﻿using NConcern;
using System.Collections.Generic;
using System.Reflection;

namespace SequenceDiagramDebuggerLib
{
	public class SequenceDiagramAspect : IAspect
	{
		static public DebuggerForm debuggerForm = null;

		public IEnumerable<IAdvice> Advise(MethodBase methodBase)
		{
			yield return Advice.Basic.Before((instance, arguments) =>
			{
				SequenceDiagramAspect.debuggerForm.BeforeMethodCall(methodBase.DeclaringType.FullName, methodBase.Name);
			});

			yield return Advice.Basic.After((instance, arguments) =>
			{
				SequenceDiagramAspect.debuggerForm.AfterMethodCall();
			});
		}
	}
}
