﻿namespace SequenceDiagramDebuggerLib
{
	partial class DebuggerForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.sequenceDiagram = new SequenceDiagramLib.View.SequenceDiagramControl();
			this.continueButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// sequenceDiagram
			// 
			this.sequenceDiagram.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.sequenceDiagram.AutoScroll = true;
			this.sequenceDiagram.AutoScrollMinSize = new System.Drawing.Size(678, 110);
			this.sequenceDiagram.BackColor = System.Drawing.Color.White;
			this.sequenceDiagram.Location = new System.Drawing.Point(12, 51);
			this.sequenceDiagram.Name = "sequenceDiagram";
			this.sequenceDiagram.Size = new System.Drawing.Size(678, 268);
			this.sequenceDiagram.SwimlaneWidth = 150;
			this.sequenceDiagram.TabIndex = 1;
			// 
			// continueButton
			// 
			this.continueButton.Location = new System.Drawing.Point(13, 13);
			this.continueButton.Name = "continueButton";
			this.continueButton.Size = new System.Drawing.Size(90, 23);
			this.continueButton.TabIndex = 2;
			this.continueButton.Text = "Continue";
			this.continueButton.UseVisualStyleBackColor = true;
			this.continueButton.Click += new System.EventHandler(this.continueButton_Click);
			// 
			// DebuggerForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(702, 331);
			this.Controls.Add(this.continueButton);
			this.Controls.Add(this.sequenceDiagram);
			this.Name = "DebuggerForm";
			this.Text = "Debugger";
			this.ResumeLayout(false);

		}

		#endregion
		private SequenceDiagramLib.View.SequenceDiagramControl sequenceDiagram;
		private System.Windows.Forms.Button continueButton;
	}
}