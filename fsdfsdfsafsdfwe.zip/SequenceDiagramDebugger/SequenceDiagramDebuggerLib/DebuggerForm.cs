﻿using SequenceDiagramLib.Model;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Threading;

namespace SequenceDiagramDebuggerLib
{
	public partial class DebuggerForm : Form
	{
		public Stack<Method> methods = new Stack<Method>();

		public DebuggerForm()
		{
			InitializeComponent();

			this.continueButton.Enabled = false;

			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;

			/*
			Participant participant0 = sequence.Participants.CreateOrGet(".");
			participant0.Activate();
			this.methods.Push(new Method(".", ""));
			*/
		}

		public DebuggerForm(Form mainForm) : this()
		{
			mainForm.FormClosing += MainForm_FormClosing;
		}

		private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.continueButton.Enabled = false;
		}

		public void BeforeMethodCall(string participantName, string methodName)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			if (this.methods.Count == 0)
			{
				Participant participant0 = sequence.Participants.CreateOrGet(participantName);
				participant0.Activate();
				sequence.Tick();

				this.methods.Push(new Method(participantName, ""));
			}

			Method parentMethod = this.methods.Peek();
			Method method = new Method(participantName, methodName);

			Participant participant = sequence.Participants.CreateOrGet(method.ParticipantName);
			Participant parentParticipant = sequence.Participants[parentMethod.ParticipantName];

			participant.Activate();
			sequence.Messages.Add(method.MethodName, parentParticipant, participant);

			this.methods.Push(method);
			sequence.Tick();
		}

		public void AfterMethodCall()
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Method method = this.methods.Pop();
			Method parentMethod = this.methods.Peek();

			Participant participant = sequence.Participants[method.ParticipantName];
			Participant parentParticipant = sequence.Participants[parentMethod.ParticipantName];

			participant.Deactivate();
			sequence.Messages.Add(method.MethodName, participant, parentParticipant, dashStyle: DashStyle.Dash);
			sequence.Tick();
		}

		private void continueButton_Click(object sender, System.EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}
	}
}
