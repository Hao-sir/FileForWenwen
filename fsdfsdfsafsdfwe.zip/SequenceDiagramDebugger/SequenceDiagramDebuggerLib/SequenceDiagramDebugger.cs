﻿using NConcern;
using SequenceDiagramDebuggerLib.SequenceDiagramTracerLib;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;

namespace SequenceDiagramDebuggerLib
{
	public class SequenceDiagramDebugger
	{
		static private List<string> namespaceFilters = null;

		static public void Init(Form mainForm, List<string> namespaceFilters)
		{
			SequenceDiagramDebugger.namespaceFilters = namespaceFilters;

			DebuggerForm form = new DebuggerForm(mainForm);
			SequenceDiagramAspect.debuggerForm = form;
			form.Show();

			//Aspect.Weave<SequenceDiagramAspect>(typeof(DebuggedAttribute));

			System.Func<MethodBase, bool> func = new System.Func<MethodBase, bool>(TargetMethod);
			Aspect.Weave<SequenceDiagramAspect>(func);
		}

		static public void Init(Form mainForm, string namespaceFilter)
		{
			Init(mainForm, new List<string>() { namespaceFilter });
		}

		static bool TargetMethod(MethodBase methodBase)
		{
			if (methodBase.DeclaringType.FullName.Contains("<Neptune>"))
				return false;

			foreach (string filter in namespaceFilters)
			{
				if (methodBase.DeclaringType.FullName.StartsWith(filter))
				{
					if (methodBase.GetCustomAttributes(typeof(DontDebugAttribute), true).Length > 0)
						return false;

					return true;
				}
			}

			return false;
		}
	}
}
