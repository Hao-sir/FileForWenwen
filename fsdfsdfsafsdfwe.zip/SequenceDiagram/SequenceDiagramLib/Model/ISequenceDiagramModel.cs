﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SequenceDiagramLib.Model
{
	public interface ISequenceDiagramModel
	{
		Sequence GetSequence();
	}
}
