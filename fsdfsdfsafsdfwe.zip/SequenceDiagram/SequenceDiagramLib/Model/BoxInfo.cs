﻿using System.Drawing;

namespace SequenceDiagramLib.Model
{
	public class BoxInfo
	{
		public string Name = "";
		public Color Color = Color.White;
	}
}
