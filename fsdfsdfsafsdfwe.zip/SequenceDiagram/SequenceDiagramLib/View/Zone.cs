﻿using SequenceDiagramLib.Model;
using System.Drawing;

namespace SequenceDiagramLib.View
{
	public class Zone
	{
		public Zone(Rectangle rectangle, string description)
		{
			this.Location = rectangle;
			this.Description = description;
		}

		public Rectangle Location = new Rectangle();
		public string Description = "";

		public Activation ActivationBox = null;
		public Participant Participant = null;
	}
}
