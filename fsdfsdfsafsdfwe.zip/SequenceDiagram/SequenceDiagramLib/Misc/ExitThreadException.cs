﻿/*
using System;

namespace SequenceDiagramLib.Misc
{
	public class ExitThreadException : Exception
	{
	}
}
*/