﻿using SequenceDiagramLib.Misc;
using SequenceDiagramLib.Model;
using System;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.PlantUmlBasedSamples
{
	public partial class BasicExamplesThreadedForm : Form
	{
		public BasicExamplesThreadedForm()
		{
			InitializeComponent();

			this.continueButton.Enabled = false;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Thread thread = new Thread(BasicExamplesThreadedForm.Run);
			thread.Start(this.sequenceDiagram.Sequence);
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void BasicExamplesThreadedForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			EnableContinueButton(true);
		}

		private void Sequence_OnExitBreak()
		{
			EnableContinueButton(false);
		}

		private static void Run(object data)
		{
			Sequence sequence = (Sequence)data;

			Participant alice = sequence.Participants.CreateOrGet("Alice");
			Participant bob = sequence.Participants.CreateOrGet("Bob");
			sequence.Messages.Add("AuthenticationRequest", alice, bob);
			sequence.Tick();

			sequence.Messages.Add("AuthenticationResponse", bob, alice, dashStyle: DashStyle.Dash);
			sequence.Tick();

			sequence.Messages.Add("Another authentication Response", bob, alice, dashStyle: DashStyle.Dash);
			sequence.Tick();
		}

		#region Thread-Safe Methods
		delegate void EnableContinueButtonCallback(bool enable);

		private void EnableContinueButton(bool enable)
		{
			if (this.InvokeRequired)
			{
				EnableContinueButtonCallback d = new EnableContinueButtonCallback(EnableContinueButton);
				this.Invoke(d, new object[] { enable });
			}
			else
			{
				FlashWindow.Flash(this);
				this.continueButton.Enabled = enable;
				this.runButton.Enabled = !enable;
			}
		}
		#endregion
	}
}
