﻿namespace SequenceDiagramTestApp.PlantUmlBasedSamples
{
	partial class DeclaringParticipant1Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.sequenceDiagram = new SequenceDiagramLib.View.SequenceDiagramControl();
			this.continueButton = new System.Windows.Forms.Button();
			this.runButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// sequenceDiagram
			// 
			this.sequenceDiagram.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.sequenceDiagram.AutoScroll = true;
			this.sequenceDiagram.AutoScrollMinSize = new System.Drawing.Size(769, 110);
			this.sequenceDiagram.BackColor = System.Drawing.Color.White;
			this.sequenceDiagram.Location = new System.Drawing.Point(12, 43);
			this.sequenceDiagram.Name = "sequenceDiagram";
			this.sequenceDiagram.Size = new System.Drawing.Size(769, 360);
			this.sequenceDiagram.SwimlaneWidth = 150;
			this.sequenceDiagram.TabIndex = 2;
			// 
			// continueButton
			// 
			this.continueButton.Location = new System.Drawing.Point(108, 12);
			this.continueButton.Name = "continueButton";
			this.continueButton.Size = new System.Drawing.Size(90, 25);
			this.continueButton.TabIndex = 1;
			this.continueButton.Text = "Continue";
			this.continueButton.UseVisualStyleBackColor = true;
			this.continueButton.Click += new System.EventHandler(this.continueButton_Click);
			// 
			// runButton
			// 
			this.runButton.Location = new System.Drawing.Point(12, 12);
			this.runButton.Name = "runButton";
			this.runButton.Size = new System.Drawing.Size(90, 25);
			this.runButton.TabIndex = 0;
			this.runButton.Text = "Run";
			this.runButton.UseVisualStyleBackColor = true;
			this.runButton.Click += new System.EventHandler(this.runButton_Click);
			// 
			// DeclaringParticipant1Form
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(793, 415);
			this.Controls.Add(this.runButton);
			this.Controls.Add(this.continueButton);
			this.Controls.Add(this.sequenceDiagram);
			this.Name = "DeclaringParticipant1Form";
			this.Text = "DeclaringParticipant1Form";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DeclaringParticipant1Form_FormClosing);
			this.ResumeLayout(false);

		}

		#endregion

		private SequenceDiagramLib.View.SequenceDiagramControl sequenceDiagram;
		private System.Windows.Forms.Button continueButton;
		private System.Windows.Forms.Button runButton;
	}
}

