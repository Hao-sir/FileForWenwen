﻿using SequenceDiagramLib.Model;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.PlantUmlBasedSamples
{
	public partial class DeclaringParticipant1Form : Form
	{
		public DeclaringParticipant1Form()
		{
			InitializeComponent();

			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;

			this.sequenceDiagram.SwimlaneWidth = 100;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence = this.sequenceDiagram.Sequence;
			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant foo1 = sequence.Participants.CreateOrGet("Foo1", color: Color.Yellow, type: EParticipantType.Actor);
			Participant foo2 = sequence.Participants.CreateOrGet("Foo2", color: Color.Yellow, type: EParticipantType.Boundary);
			sequence.Messages.Add("To boundary", foo1, foo2);
			sequence.Tick();

			Participant foo3 = sequence.Participants.CreateOrGet("Foo3", color: Color.Yellow, type: EParticipantType.Control);
			sequence.Messages.Add("To control", foo1, foo3);
			sequence.Tick();

			Participant foo4 = sequence.Participants.CreateOrGet("Foo4", color: Color.Yellow, type: EParticipantType.Entity);
			sequence.Messages.Add("To entity", foo1, foo4);
			sequence.Tick();

			Participant foo5 = sequence.Participants.CreateOrGet("Foo5", color: Color.Yellow, type: EParticipantType.Database);
			sequence.Messages.Add("To database", foo1, foo5);
			sequence.Tick();

			Participant foo6 = sequence.Participants.CreateOrGet("Foo6", color: Color.Yellow, type: EParticipantType.Collections);
			sequence.Messages.Add("To collections", foo1, foo6);
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.Continue();
		}

		private void BasicExamplesThreadedForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}

		private void DeclaringParticipant1Form_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}
	}
}
