﻿using SequenceDiagramLib.Model;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.PlantUmlBasedSamples
{
	public partial class LifelineActivationAndDestruction3Form : Form
	{
		public LifelineActivationAndDestruction3Form()
		{
			InitializeComponent();

			this.continueButton.Enabled = false;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant alice = sequence.Participants.CreateOrGet("alice");
			Participant bob = sequence.Participants.CreateOrGet("bob");
			sequence.Messages.Add("hello", alice, bob);
			bob.Activate();
			sequence.Tick();

			sequence.Messages.Add("self call", bob);
			bob.Activate();
			sequence.Tick();

			Participant bill = sequence.Participants.CreateOrGet("bill");
			sequence.Messages.Add("hello from thread 2", bill, bob);
			bob.Activate("", color: Color.FromArgb(0x00, 0x55, 0x00));
			sequence.Tick();

			Participant george = sequence.Participants.CreateOrGet("george", createNow: true);
			sequence.Messages.Add("create", bob, george);
			sequence.Tick();

			sequence.Messages.Add("done in thead 2", bob, bill, dashStyle: DashStyle.Dot);
			bob.Deactivate();
			sequence.Tick();

			bob.Deactivate();
			sequence.Messages.Add("rc", bob, dashStyle: DashStyle.Dot);
			sequence.Tick();

			george.Destroy();
			sequence.Messages.Add("delete", bob, george);
			sequence.Tick();

			bob.Deactivate();
			sequence.Messages.Add("success", bob, alice, dashStyle: DashStyle.Dot);
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void LifelineActivationAndDestruction3Form_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}
	}
}
