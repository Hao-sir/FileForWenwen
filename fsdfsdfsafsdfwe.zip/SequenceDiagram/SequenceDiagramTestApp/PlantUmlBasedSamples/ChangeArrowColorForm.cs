﻿using SequenceDiagramLib.Model;
using SequenceDiagramLib.Presenter;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.PlantUmlBasedSamples
{
	public partial class ChangeArrowColorForm : Form
	{
		public ChangeArrowColorForm()
		{
			InitializeComponent();

			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}


		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant bob = sequence.Participants.CreateOrGet("Bob");
			Participant alice = sequence.Participants.CreateOrGet("Alice");
			sequence.Messages.Add("hello", bob, alice, color: Color.Red);
			sequence.Tick();

			sequence.Messages.Add("ok", alice, bob, color: Color.Blue);
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void BasicExamplesThreadedForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}

		private void ChangeArrowColorForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}
	}
}
