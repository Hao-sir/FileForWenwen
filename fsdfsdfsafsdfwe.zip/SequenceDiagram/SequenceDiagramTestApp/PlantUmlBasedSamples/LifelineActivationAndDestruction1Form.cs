﻿using SequenceDiagramLib.Model;
using System;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.PlantUmlBasedSamples
{
	public partial class LifelineActivationAndDestruction1Form : Form
	{
		public LifelineActivationAndDestruction1Form()
		{
			InitializeComponent();

			this.continueButton.Enabled = false;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant user = sequence.Participants.CreateOrGet("User");
			Participant a = sequence.Participants.CreateOrGet("A");
			sequence.Messages.Add("DoWork", user, a);
			a.Activate();
			sequence.Tick();

			Participant b = sequence.Participants.CreateOrGet("B");
			sequence.Messages.Add("<< createRequest >>", a, b);
			b.Activate();
			sequence.Tick();

			Participant c = sequence.Participants.CreateOrGet("C");
			sequence.Messages.Add("DoWork", b, c);
			c.Activate();
			sequence.Tick();

			sequence.Messages.Add("WorkDone", c, b, dashStyle: DashStyle.Dot);
			c.Deactivate();
			c.Destroy();
			sequence.Tick();

			sequence.Messages.Add("RequestCreated", b, a, dashStyle: DashStyle.Dot);
			b.Deactivate();
			sequence.Tick();

			sequence.Messages.Add("Done", a, user);
			a.Deactivate();
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void BasicExamplesThreadedForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}

		private void LifelineActivationAndDestruction1Form_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}
	}
}
