﻿using SequenceDiagramLib.Model;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.PlantUmlBasedSamples
{
	public partial class LifelineActivationAndDestruction2Form : Form
	{
		public LifelineActivationAndDestruction2Form()
		{
			InitializeComponent();

			this.continueButton.Enabled = false;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant user = sequence.Participants.CreateOrGet("User");
			Participant a = sequence.Participants.CreateOrGet("A");
			sequence.Messages.Add("DoWork", user, a);
			a.Activate(color: Color.FromArgb(0xff, 0xbb, 0xbb));
			sequence.Tick();

			sequence.Messages.Add("Internal call", a);
			a.Activate(color: Color.DarkSalmon);
			sequence.Tick();

			Participant b = sequence.Participants.CreateOrGet("B");
			sequence.Messages.Add("<< createRequest >>", a, b);
			b.Activate();
			sequence.Tick();

			sequence.Messages.Add("RequestCreated", b, a, dashStyle: DashStyle.Dash);
			b.Deactivate();
			a.Deactivate();
			sequence.Tick();

			sequence.Messages.Add("Done", a, user);
			a.Deactivate();
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void LifelineActivationAndDestruction2Form_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}
	}
}
