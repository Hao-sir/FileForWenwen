﻿using SequenceDiagramLib.Model;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.PlantUmlBasedSamples
{
	public partial class ParticipantsEncompassForm : Form
	{
		public ParticipantsEncompassForm()
		{
			InitializeComponent();

			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Box box = sequence.Boxes.CreateOrGet("Internal Service");
			box.Color = Color.LightBlue;
			Participant bob = sequence.Participants.CreateOrGet("bob", box: box);
			Participant alice = sequence.Participants.CreateOrGet("alice", box: box);
			sequence.Messages.Add("hello", bob, alice);
			sequence.Tick();

			Participant other = sequence.Participants.CreateOrGet("other");
			sequence.Messages.Add("hello", alice, other);
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void ParticipantsEncompassForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}
	}
}
