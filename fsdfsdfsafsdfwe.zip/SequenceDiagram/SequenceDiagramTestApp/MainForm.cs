﻿using SequenceDiagramTestApp.PlantUmlBasedSamples;
using System;
using System.Windows.Forms;

namespace SequenceDiagramTestApp
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void basicExamplesButton_Click(object sender, EventArgs e)
		{
			BasicExamplesForm form = new BasicExamplesForm();
			form.ShowDialog();
		}

		private void declaringParticipant1Button_Click(object sender, EventArgs e)
		{
			DeclaringParticipant1Form form = new DeclaringParticipant1Form();
			form.ShowDialog();
		}

		private void declaringParticipant2Button_Click(object sender, EventArgs e)
		{
			DeclaringParticipant2Form form = new DeclaringParticipant2Form();
			form.ShowDialog();
		}

		private void messageToSelfButton_Click(object sender, EventArgs e)
		{
			MessageToSelfForm form = new MessageToSelfForm();
			form.ShowDialog();
		}

		private void useNonLettersInParticipantsButton_Click(object sender, EventArgs e)
		{
			UseNonlettersInParticipantsForm form = new UseNonlettersInParticipantsForm();
			form.ShowDialog();
		}

		private void changeArrowColorButton_Click(object sender, EventArgs e)
		{
			ChangeArrowColorForm form = new ChangeArrowColorForm();
			form.ShowDialog();
		}

		private void lifelineActivationAndDestruction1Button_Click(object sender, EventArgs e)
		{
			LifelineActivationAndDestruction1Form form = new LifelineActivationAndDestruction1Form();
			form.ShowDialog();
		}

		private void lifelineActivationAndDestruction2Button_Click(object sender, EventArgs e)
		{
			LifelineActivationAndDestruction2Form form = new LifelineActivationAndDestruction2Form();
			form.ShowDialog();
		}

		private void lifelineActivationAndDestruction3Button_Click(object sender, EventArgs e)
		{
			LifelineActivationAndDestruction3Form form = new LifelineActivationAndDestruction3Form();
			form.ShowDialog();
		}

		private void participantCreationButton_Click(object sender, EventArgs e)
		{
			ParticipantCreationForm form = new ParticipantCreationForm();
			form.ShowDialog();
		}

		private void participantsEncompassButton_Click(object sender, EventArgs e)
		{
			ParticipantsEncompassForm form = new ParticipantsEncompassForm();
			form.ShowDialog();
		}

		private void basicExamplesThreadedButton_Click(object sender, EventArgs e)
		{
			BasicExamplesThreadedForm form = new BasicExamplesThreadedForm();
			form.ShowDialog();
		}
	}
}
