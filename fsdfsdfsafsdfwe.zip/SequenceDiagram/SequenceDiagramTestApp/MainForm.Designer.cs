﻿namespace SequenceDiagramTestApp
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.basicExamplesButton = new System.Windows.Forms.Button();
			this.basicExamplesThreadedButton = new System.Windows.Forms.Button();
			this.declaringParticipant1Button = new System.Windows.Forms.Button();
			this.declaringParticipant2Button = new System.Windows.Forms.Button();
			this.messageToSelfButton = new System.Windows.Forms.Button();
			this.useNonLettersInParticipantsButton = new System.Windows.Forms.Button();
			this.changeArrowColorButton = new System.Windows.Forms.Button();
			this.lifelineActivationAndDestruction1Button = new System.Windows.Forms.Button();
			this.lifelineActivationAndDestruction2Button = new System.Windows.Forms.Button();
			this.lifelineActivationAndDestruction3Button = new System.Windows.Forms.Button();
			this.participantCreationButton = new System.Windows.Forms.Button();
			this.participantsEncompassButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// basicExamplesButton
			// 
			this.basicExamplesButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.basicExamplesButton.Location = new System.Drawing.Point(12, 12);
			this.basicExamplesButton.Name = "basicExamplesButton";
			this.basicExamplesButton.Size = new System.Drawing.Size(469, 28);
			this.basicExamplesButton.TabIndex = 0;
			this.basicExamplesButton.Text = "Basic examples";
			this.basicExamplesButton.UseVisualStyleBackColor = true;
			this.basicExamplesButton.Click += new System.EventHandler(this.basicExamplesButton_Click);
			// 
			// basicExamplesThreadedButton
			// 
			this.basicExamplesThreadedButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.basicExamplesThreadedButton.Location = new System.Drawing.Point(12, 408);
			this.basicExamplesThreadedButton.Name = "basicExamplesThreadedButton";
			this.basicExamplesThreadedButton.Size = new System.Drawing.Size(469, 28);
			this.basicExamplesThreadedButton.TabIndex = 11;
			this.basicExamplesThreadedButton.Text = "Basic examples (Threaded)";
			this.basicExamplesThreadedButton.UseVisualStyleBackColor = true;
			this.basicExamplesThreadedButton.Click += new System.EventHandler(this.basicExamplesThreadedButton_Click);
			// 
			// declaringParticipant1Button
			// 
			this.declaringParticipant1Button.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.declaringParticipant1Button.Location = new System.Drawing.Point(12, 46);
			this.declaringParticipant1Button.Name = "declaringParticipant1Button";
			this.declaringParticipant1Button.Size = new System.Drawing.Size(469, 28);
			this.declaringParticipant1Button.TabIndex = 1;
			this.declaringParticipant1Button.Text = "Declaring participant (1)";
			this.declaringParticipant1Button.UseVisualStyleBackColor = true;
			this.declaringParticipant1Button.Click += new System.EventHandler(this.declaringParticipant1Button_Click);
			// 
			// declaringParticipant2Button
			// 
			this.declaringParticipant2Button.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.declaringParticipant2Button.Location = new System.Drawing.Point(12, 80);
			this.declaringParticipant2Button.Name = "declaringParticipant2Button";
			this.declaringParticipant2Button.Size = new System.Drawing.Size(469, 28);
			this.declaringParticipant2Button.TabIndex = 2;
			this.declaringParticipant2Button.Text = "Declaring participant (2)";
			this.declaringParticipant2Button.UseVisualStyleBackColor = true;
			this.declaringParticipant2Button.Click += new System.EventHandler(this.declaringParticipant2Button_Click);
			// 
			// messageToSelfButton
			// 
			this.messageToSelfButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.messageToSelfButton.Location = new System.Drawing.Point(12, 148);
			this.messageToSelfButton.Name = "messageToSelfButton";
			this.messageToSelfButton.Size = new System.Drawing.Size(469, 28);
			this.messageToSelfButton.TabIndex = 4;
			this.messageToSelfButton.Text = "Message to Self";
			this.messageToSelfButton.UseVisualStyleBackColor = true;
			this.messageToSelfButton.Click += new System.EventHandler(this.messageToSelfButton_Click);
			// 
			// useNonLettersInParticipantsButton
			// 
			this.useNonLettersInParticipantsButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.useNonLettersInParticipantsButton.Location = new System.Drawing.Point(12, 114);
			this.useNonLettersInParticipantsButton.Name = "useNonLettersInParticipantsButton";
			this.useNonLettersInParticipantsButton.Size = new System.Drawing.Size(469, 28);
			this.useNonLettersInParticipantsButton.TabIndex = 3;
			this.useNonLettersInParticipantsButton.Text = "Use non-letters in participants";
			this.useNonLettersInParticipantsButton.UseVisualStyleBackColor = true;
			this.useNonLettersInParticipantsButton.Click += new System.EventHandler(this.useNonLettersInParticipantsButton_Click);
			// 
			// changeArrowColorButton
			// 
			this.changeArrowColorButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.changeArrowColorButton.Location = new System.Drawing.Point(12, 182);
			this.changeArrowColorButton.Name = "changeArrowColorButton";
			this.changeArrowColorButton.Size = new System.Drawing.Size(469, 28);
			this.changeArrowColorButton.TabIndex = 5;
			this.changeArrowColorButton.Text = "Change arrow color";
			this.changeArrowColorButton.UseVisualStyleBackColor = true;
			this.changeArrowColorButton.Click += new System.EventHandler(this.changeArrowColorButton_Click);
			// 
			// lifelineActivationAndDestruction1Button
			// 
			this.lifelineActivationAndDestruction1Button.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lifelineActivationAndDestruction1Button.Location = new System.Drawing.Point(12, 217);
			this.lifelineActivationAndDestruction1Button.Name = "lifelineActivationAndDestruction1Button";
			this.lifelineActivationAndDestruction1Button.Size = new System.Drawing.Size(469, 28);
			this.lifelineActivationAndDestruction1Button.TabIndex = 6;
			this.lifelineActivationAndDestruction1Button.Text = "Lifeline activation and destruction (1)";
			this.lifelineActivationAndDestruction1Button.UseVisualStyleBackColor = true;
			this.lifelineActivationAndDestruction1Button.Click += new System.EventHandler(this.lifelineActivationAndDestruction1Button_Click);
			// 
			// lifelineActivationAndDestruction2Button
			// 
			this.lifelineActivationAndDestruction2Button.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lifelineActivationAndDestruction2Button.Location = new System.Drawing.Point(12, 251);
			this.lifelineActivationAndDestruction2Button.Name = "lifelineActivationAndDestruction2Button";
			this.lifelineActivationAndDestruction2Button.Size = new System.Drawing.Size(469, 28);
			this.lifelineActivationAndDestruction2Button.TabIndex = 7;
			this.lifelineActivationAndDestruction2Button.Text = "Lifeline activation and destruction (2)";
			this.lifelineActivationAndDestruction2Button.UseVisualStyleBackColor = true;
			this.lifelineActivationAndDestruction2Button.Click += new System.EventHandler(this.lifelineActivationAndDestruction2Button_Click);
			// 
			// lifelineActivationAndDestruction3Button
			// 
			this.lifelineActivationAndDestruction3Button.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lifelineActivationAndDestruction3Button.Location = new System.Drawing.Point(12, 285);
			this.lifelineActivationAndDestruction3Button.Name = "lifelineActivationAndDestruction3Button";
			this.lifelineActivationAndDestruction3Button.Size = new System.Drawing.Size(469, 28);
			this.lifelineActivationAndDestruction3Button.TabIndex = 8;
			this.lifelineActivationAndDestruction3Button.Text = "Lifeline activation and destruction (3)";
			this.lifelineActivationAndDestruction3Button.UseVisualStyleBackColor = true;
			this.lifelineActivationAndDestruction3Button.Click += new System.EventHandler(this.lifelineActivationAndDestruction3Button_Click);
			// 
			// participantCreationButton
			// 
			this.participantCreationButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.participantCreationButton.Location = new System.Drawing.Point(12, 319);
			this.participantCreationButton.Name = "participantCreationButton";
			this.participantCreationButton.Size = new System.Drawing.Size(469, 28);
			this.participantCreationButton.TabIndex = 9;
			this.participantCreationButton.Text = "Participant creation";
			this.participantCreationButton.UseVisualStyleBackColor = true;
			this.participantCreationButton.Click += new System.EventHandler(this.participantCreationButton_Click);
			// 
			// participantsEncompassButton
			// 
			this.participantsEncompassButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.participantsEncompassButton.Location = new System.Drawing.Point(12, 353);
			this.participantsEncompassButton.Name = "participantsEncompassButton";
			this.participantsEncompassButton.Size = new System.Drawing.Size(469, 28);
			this.participantsEncompassButton.TabIndex = 10;
			this.participantsEncompassButton.Text = "Participants encompass";
			this.participantsEncompassButton.UseVisualStyleBackColor = true;
			this.participantsEncompassButton.Click += new System.EventHandler(this.participantsEncompassButton_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(493, 449);
			this.Controls.Add(this.participantsEncompassButton);
			this.Controls.Add(this.participantCreationButton);
			this.Controls.Add(this.lifelineActivationAndDestruction3Button);
			this.Controls.Add(this.lifelineActivationAndDestruction2Button);
			this.Controls.Add(this.lifelineActivationAndDestruction1Button);
			this.Controls.Add(this.changeArrowColorButton);
			this.Controls.Add(this.useNonLettersInParticipantsButton);
			this.Controls.Add(this.messageToSelfButton);
			this.Controls.Add(this.declaringParticipant2Button);
			this.Controls.Add(this.declaringParticipant1Button);
			this.Controls.Add(this.basicExamplesThreadedButton);
			this.Controls.Add(this.basicExamplesButton);
			this.Name = "MainForm";
			this.Text = "Schema Diagram Control Samples";
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Button basicExamplesButton;
		private System.Windows.Forms.Button basicExamplesThreadedButton;
		private System.Windows.Forms.Button declaringParticipant1Button;
		private System.Windows.Forms.Button declaringParticipant2Button;
		private System.Windows.Forms.Button messageToSelfButton;
		private System.Windows.Forms.Button useNonLettersInParticipantsButton;
		private System.Windows.Forms.Button changeArrowColorButton;
		private System.Windows.Forms.Button lifelineActivationAndDestruction1Button;
		private System.Windows.Forms.Button lifelineActivationAndDestruction2Button;
		private System.Windows.Forms.Button lifelineActivationAndDestruction3Button;
		private System.Windows.Forms.Button participantCreationButton;
		private System.Windows.Forms.Button participantsEncompassButton;
	}
}