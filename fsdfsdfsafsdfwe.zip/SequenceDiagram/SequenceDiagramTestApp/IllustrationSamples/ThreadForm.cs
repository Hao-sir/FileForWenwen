﻿using SequenceDiagramLib.Model;
using System;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.IlustrationSamples
{
	public partial class ThreadForm : Form
	{
		public ThreadForm()
		{
			InitializeComponent();

			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;

			this.sequenceDiagram.SwimlaneWidth = 200;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant main = sequence.Participants.CreateOrGet("Main Thread");
			Participant work = sequence.Participants.CreateOrGet("Work Thread");
			sequence.Messages.Add("Run", main, work);
			sequence.Tick();

			sequence.Messages.Add("UpdateModel", work);
			sequence.Tick();

			sequence.Messages.Add("Monitor.Wait", work, main);
			sequence.Tick();

			sequence.Messages.Add("Wait for continue", main);
			sequence.Tick();

			sequence.Messages.Add("Monitor.Pulse", main, work);
			sequence.Tick();

			sequence.Messages.Add("Return", work, main);
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void ThreadForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}
	}
}
