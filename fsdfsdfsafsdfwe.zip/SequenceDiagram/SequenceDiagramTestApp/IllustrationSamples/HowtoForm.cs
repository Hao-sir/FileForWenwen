﻿using SequenceDiagramLib.Model;
using System;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.IlustrationSamples
{
	public partial class HowtoForm : Form
	{
		public HowtoForm()
		{
			InitializeComponent();

			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;

			this.sequenceDiagram.SwimlaneWidth = 200;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant a = sequence.Participants.CreateOrGet("A");
			Participant b = sequence.Participants.CreateOrGet("B");
			sequence.Messages.Add("Create request", a, b);
			sequence.Tick();

			sequence.Messages.Add("Return", b, a);
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void IntroForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}
	}
}
