﻿using SequenceDiagramLib.Model;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.IlustrationSamples
{
	public partial class UsageScenario2Form : Form
	{
		public UsageScenario2Form()
		{
			InitializeComponent();

			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;

			this.sequenceDiagram.SwimlaneWidth = 200;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant calculate = sequence.Participants.CreateOrGet(
				"Calculate", color: Color.FromArgb(255, 153, 0), textColor: Color.White);
			calculate.Activate();
			sequence.Tick();

			Participant combination = sequence.Participants.CreateOrGet(
				"Combination", color: Color.FromArgb(255, 153, 0), textColor: Color.White);
			sequence.Messages.Add("(5,2)", calculate, combination);
			combination.Activate();
			sequence.Tick();

			Participant factorial = sequence.Participants.CreateOrGet(
				"Factorial", color: Color.FromArgb(255, 153, 0), textColor: Color.White);
			sequence.Messages.Add("(5)", combination, factorial);
			factorial.Activate();
			sequence.Tick();

			sequence.Messages.Add("(120)", factorial, combination);
			factorial.Deactivate();
			sequence.Tick();

			sequence.Messages.Add("(2)", combination, factorial);
			factorial.Activate();
			sequence.Tick();

			sequence.Messages.Add("(2)", factorial, combination);
			factorial.Deactivate();
			sequence.Tick();

			sequence.Messages.Add("(3)", combination, factorial);
			factorial.Activate();
			sequence.Tick();

			sequence.Messages.Add("(6)", factorial, combination);
			factorial.Deactivate();
			sequence.Tick();

			sequence.Messages.Add("(10)", combination, calculate);
			combination.Deactivate();
			sequence.Tick();

			calculate.Deactivate();
			sequence.Tick();

		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void UsageScenario2Form_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}
	}
}
