﻿using SequenceDiagramLib.Model;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SequenceDiagramTestApp.IlustrationSamples
{
	public partial class UsageScenario1Form : Form
	{
		public UsageScenario1Form()
		{
			InitializeComponent();

			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;

			this.sequenceDiagram.SwimlaneWidth = 200;

			Sequence sequence = this.sequenceDiagram.Sequence;

			sequence.OnEnterBreak += Sequence_OnEnterBreak;
			sequence.OnExitBreak += Sequence_OnExitBreak;
		}

		private void runButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;

			Participant microservice1 = sequence.Participants.CreateOrGet(
				"Microservice 1", color: Color.FromArgb(255, 153, 0), textColor: Color.White);
			microservice1.Activate();
			sequence.Tick();

			Participant microservice2 = sequence.Participants.CreateOrGet(
				"Microservice 2", color: Color.FromArgb(255, 153, 0), textColor: Color.White);
			sequence.Messages.Add("Call", microservice1, microservice2);
			microservice2.Activate();
			sequence.Tick();

			Participant microservice3 = sequence.Participants.CreateOrGet(
				"Microservice 3", color: Color.FromArgb(255, 153, 0), textColor: Color.White);
			sequence.Messages.Add("Call", microservice2, microservice3);
			microservice3.Activate();
			sequence.Tick();

			sequence.Messages.Add("Return", microservice3, microservice2);
			microservice3.Deactivate();
			sequence.Tick();

			sequence.Messages.Add("Return", microservice2, microservice1);
			microservice2.Deactivate();
			sequence.Tick();

			microservice1.Deactivate();
			sequence.Tick();
		}

		private void continueButton_Click(object sender, EventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Continue();
		}

		private void UsageScenario1Form_FormClosing(object sender, FormClosingEventArgs e)
		{
			Sequence sequence = this.sequenceDiagram.Sequence;
			sequence.Exit();
		}

		private void Sequence_OnEnterBreak()
		{
			this.runButton.Enabled = false;
			this.continueButton.Enabled = true;
		}

		private void Sequence_OnExitBreak()
		{
			this.runButton.Enabled = true;
			this.continueButton.Enabled = false;
		}
	}
}
